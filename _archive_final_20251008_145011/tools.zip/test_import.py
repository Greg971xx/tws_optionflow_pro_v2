import importlib, sys, os
print("sys.path[0] =", sys.path[0])
m = importlib.import_module('ui.modules.har_rv_viewer')
print("Loaded:", m.__file__)
